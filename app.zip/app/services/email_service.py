# import smtplib
# from email.mime.multipart import MIMEMultipart
# from email.mime.text import MIMEText
# from email.mime.base import MIMEBase
# from email import encoders
# from app.services.otp_service import generate_otp
# from fastapi import FastAPI, BackgroundTasks
# from app.models.email_signer import SignerEmail


# def send_otp_to_signer(signer_email: SignerEmail, background_tasks: BackgroundTasks):
#     otp = generate_otp(signer_email.email)
#     background_tasks.add_task(send_otp_email, signer_email.email, otp)
#     return {"message": "OTP sent successfully"}

# def send_otp_email(signer_email: str, otp: str):
#     subject = "OTP Verification"
#     body = f"Your OTP: {otp}"
#     send_email(signer_email, subject, body)

# def send_email(to_address, subject, body):
#     # Your email configuration
#     from_address = "lokesh.ksn@mind-graph.com"
#     password = "ttyx npiw jpku oxeo3"

#     # Create message container - the correct MIME type is multipart/alternative.
#     msg = MIMEMultipart()
#     msg['From'] = from_address
#     msg['To'] = to_address
#     msg['Subject'] = subject

#     # Attach body to the email
#     msg.attach(MIMEText(body, 'plain'))

#     # Start the SMTP session
#     server = smtplib.SMTP('smtp.gmail.com', 587)  # Change according to your email provider
#     server.starttls()
#     server.login(from_address, password)

#     # Convert the message to a string and send it
#     text = msg.as_string()
#     server.sendmail(from_address, to_address, text)

#     # Close the SMTP session
#     server.quit()


from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig
from .otp_service import generate_otp
from app.config import settings
from pymongo import MongoClient

app = FastAPI()

class EmailRequest(BaseModel):
    to: str
    subject: str
    body: str

mongo_uri = "mongodb+srv://loki_user:loki_password@clmdemo.1yw93ku.mongodb.net/?retryWrites=true&w=majority&appName=Clmdemo"
client = MongoClient(mongo_uri)
db = client['CLMDigiSignDB']

# conf = ConnectionConfig(
#     MAIL_USERNAME = "apikey",
#     MAIL_PASSWORD = "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",
#     MAIL_FROM = "lokesh.ksn@mind-graph.com",
#     MAIL_PORT = 465,
#     MAIL_SERVER = "smtp.sendgrid.net",
#     MAIL_SSL_TLS = True , # Specify whether SSL/TLS should be used for email
#     USE_CREDENTIALS = True,
#     MAIL_STARTTLS=True
# )
    
# conf = ConnectionConfig(
#     MAIL_USERNAME="apikey",
#     MAIL_PASSWORD="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",
#     MAIL_FROM="yosuva.be@mind-graph.com",
#     MAIL_PORT=587,
#     MAIL_SERVER="smtp.sendgrid.net",
#     MAIL_STARTTLS=True,
#     USE_CREDENTIALS=True,MAIL_SSL_TLS = True

# )


from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib

def send_email(receiver_email: str, subject: str, body: str):
    # Create message container
    msg = MIMEMultipart()
    msg['From'] = settings.SMTP_USERNAME
    msg['To'] = receiver_email
    msg['Subject'] = subject

    # Add body to email
    msg.attach(MIMEText(body, 'plain'))

    # Send the message via our SMTP server
    with smtplib.SMTP(settings.SMTP_SERVER, settings.SMTP_PORT) as server:
        server.starttls()
        server.login(settings.SMTP_USERNAME, settings.SMTP_PASSWORD)
        server.send_message(msg)

    print("Email sent successfully to", receiver_email)


def send_otp_to_signer(signer_email: str):
    otp = generate_otp(signer_email)
    send_email(signer_email, "OTP Verification", f"Your OTP: {otp}")
    return {"message": "OTP sent successfully", "otp": otp}

def send_password_reset_email(receiver_email: str, reset_link: str):
    subject = "Password Reset Request"
    body = f"Please click on the following link to reset your password: {reset_link}"
    send_email(receiver_email, subject, body)

def notify_watchers(document_id, update_message):
# Fetch the document to get watcher details
    print("In notify Watchers documentId ",document_id)
    document = db.documents.find_one({"document_id": document_id})
    print("check in notify watchers: ",document)
    if not document or 'watchers' not in document:
        print("No watchers found for this document.")
        return

    watchers = document['watchers']
    subject = "Update on Document Signing Process"
    print("watchers:  ",watchers)
    for watcher in watchers:
        email = watcher['email']
        print("watcher email: ",email)
        if email:
            send_email(email, subject, update_message)


# def notify_watchers_about_document_creation(watchers, document_id, document_data):
#     subject = "Assignment to Document Signing Process"
#     for watcher in watchers:
#         email = watcher.get('email')
#         if email:
#             body = (f"You have been assigned as a watcher for the document ID {document_id}.\n"
#                     f"Document Name: {document_data.get('agreement_name')}\n"
#                     f"Document Type: {document_data.get('agreement_type')}\n"
#                     "Please monitor the signing process accordingly.")
#             send_email(email, subject, body)
            
def notify_watchers_about_document_creation(watchers, document_id, document_data):
    subject = "Assignment to Document Signing Process"
    for watcher in watchers:
        email = watcher.get('email')
        if email:
            body = (f"Dear Watcher,\n\n"
                    f"We would like to inform you that you have been assigned as a watcher for the document with ID {document_id}.\n"
                    f"Document ID: {document_id}\n"
                    f"Document Name: {document_data.get('agreement_name')}\n"
                    f"Document Type: {document_data.get('agreement_type')}\n\n"
                    "Your role is crucial in monitoring the signing process of this document.\n"
                    "Please ensure to keep track of any updates or changes as necessary.\n\n"
                    "Thank you for your attention to this matter.\n\n"
                    "Best regards,\n{settings.company_name}")
            send_email(email, subject, body)
