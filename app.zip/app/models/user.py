class User:
    def __init__(self, email, password, roles, name, phone_number):
        self.email = email
        self.password = password
        self.roles = roles
        self.name = name
        self.phone_number = phone_number
