from fastapi import APIRouter, HTTPException, Body, Depends,Request,status
from typing import Dict
from uuid import uuid4
from pydantic import BaseModel
from app.services.email_service import send_email, send_password_reset_email,notify_watchers_about_document_creation
from app.services.otp_service import generate_otp, verify_otp
from app.utils.db_utils import get_next_sequence, update_password_in_database
from app.utils.auth_utils import get_current_user
from app.dependencies.auth_logic import verify_user_role
from pymongo import MongoClient
from app.utils.file_utils import save_document
from typing import List
import jwt
from app.utils.decorators import role_required
from app.config import Settings
from fastapi.security import OAuth2PasswordBearer
import string 
import random

# Define the OAuth2PasswordBearer for token authentication
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


admin_router = APIRouter()
mongo_uri = "mongodb+srv://loki_user:loki_password@clmdemo.1yw93ku.mongodb.net/?retryWrites=true&w=majority&appName=Clmdemo"
client = MongoClient(mongo_uri)
db = client['CLMDigiSignDB']
temp_storage = {}  # Temporary storage for admin data during OTP process

# Define the secret key and algorithm for JWT tokens
SECRET_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
ALGORITHM = "HS256"
settings = Settings()

# Include this function to validate JWT tokens in incoming requests
async def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email = payload.get("email")
        
        # Replace the following with your custom logic to retrieve user information from the token
        user = db.users.find_one({"email": email})
        print(user)
        if user is None:
            raise HTTPException(status_code=401, detail="User not found")

        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    
temp_storage: Dict[str, dict] = {}

def generate_password(admin_email, length=8):
    characters = string.ascii_letters + string.digits
    password = ''.join(random.choice(characters) for _ in range(length))
    return password

from datetime import datetime, timedelta

@admin_router.post('/create_admin')
async def create_admin(request: Request, current_user: dict = Depends(get_current_user)):
    # Check if the current superadmin has permission to create admins
    if current_user.get('allow_create_admins', 'False') != 'True':
        raise HTTPException(status_code=403, detail="Superadmin does not have permission to create admins")

    data = await request.json()
    admin_email = data.get('email')

    # Generate a random password for the admin
    password = generate_password(admin_email)

    # Generate separate OTPs for the superadmin and admin
    admin_otp = generate_otp(admin_email)
    superadmin_otp = generate_otp(current_user['email'])

    print("Superadmin OTP:", superadmin_otp)
    print("Admin OTP:", admin_otp)

    # Check if an OTP record already exists for the admin email
    existing_otp_record = db.otps.find_one({"email": admin_email})

    if existing_otp_record:
        # Update the existing OTP record with new OTP value and expiry time
        db.otps.update_one(
            {"email": admin_email},
            {"$set": {"otp": admin_otp, "expiry": datetime.now() + timedelta(minutes=5)}}
        )
    else:
        # Store the OTP temporarily in the database
        otp_expiry = datetime.now() + timedelta(minutes=5) # Set expiry time for OTP
        db.otps.insert_one({"email": admin_email, "otp": admin_otp, "expiry": otp_expiry})

    print("OTP records stored in the database")
    print(admin_email)
    # Send OTPs to the superadmin and admin
    send_email(current_user['email'], "OTP Verification", f"Dear Superadmin,\n\nThank you for initiating the admin creation process. Your One-Time Password (OTP) for verification is: {superadmin_otp}\n\nPlease use this OTP to proceed with the creation process.\n\nBest regards,\n{settings.company_name}")

    send_email(admin_email, "OTP Verification", f"Dear Admin,\n\nAn OTP has been generated for your admin creation process. Your One-Time Password (OTP) for verification is: {admin_otp}\n\nKindly use this OTP to complete the creation process.\n\nBest regards,\n{settings.company_name}")

    print("OTP emails sent")

    # Temporarily store the admin data
    temp_storage[admin_email] = {**data, 'password': password}

    return {"message": "OTPs sent to superadmin and admin for verification", "status code": 200}

@admin_router.post('/verify_otp')
async def verify_admin_creation_otp(request: Request, current_user: dict = Depends(get_current_user)):
    data = await request.json()
    admin_email = data.get('admin_email')
    otp = data.get('otp')

    superadmin_otp = otp.get('superadmin')
    admin_otp = otp.get('admin')

    # Fetch the OTP for the superadmin and admin from the database
    superadmin_otp_record = db.otps.find_one({"email": current_user['email']})
    admin_otp_record = db.otps.find_one({"email": admin_email})

    # Verify the OTP for both superadmin and admin
    superadmin_otp_verified = superadmin_otp_record and superadmin_otp_record['otp'] == superadmin_otp and datetime.now() < superadmin_otp_record['expiry']
    print(superadmin_otp_verified)
    admin_otp_verified = admin_otp_record and admin_otp_record['otp'] == admin_otp and datetime.now() < admin_otp_record['expiry']
    print(admin_otp_verified)

    if superadmin_otp_verified and admin_otp_verified:
        admin_data = temp_storage.pop(admin_email, None)
        if not admin_data:
            raise HTTPException(status_code=404, detail="Admin data not found")

        # Generate a unique admin ID
        admin_id = get_next_sequence(db, 'adminid')

        # Create the admin user with admin_id
        user = {
            "admin_id": admin_id,
            "email": admin_email,
            "password": admin_data['password'],
            "roles": ['admin'],
            "name": admin_data['name'],
            "phone_number": admin_data['phone_number'],
            "active_status": "true"
        }
        db.users.insert_one(user)

        # Delete the OTPs from the database
        db.otps.delete_many({"email": {"$in": [current_user['email'], admin_email]}})

        # Send email to the new admin with credentials
        email_body = f"Subject: Your Admin Credentials\n\nDear {admin_data['name']},\n\nCongratulations! You have been successfully registered as an admin on our platform.\n\nHere are your login credentials:\nEmail: {admin_email}\nPassword: {admin_data['password']}\n\nPlease keep your credentials secure and do not share them with anyone.\n\nIf you have any questions or need assistance, feel free to reach out to our support team at {settings.support_email} or call us at {settings.support_phone_number}.\n\nThank you for choosing us!\n\nBest Regards,\n{settings.company_name}"
        send_email(admin_email, "Your Admin Credentials", email_body)

        return {"message": "Admin created successfully", "admin_id": admin_id, "status": 200}
    else:
        raise HTTPException(status_code=401, detail="Invalid or expired OTP")

@admin_router.get('/get_admins')
async def get_admins(current_user: dict = Depends(get_current_user)):
    admin_records = db.users.find({"roles": "admin"}, {"password": 0})  # Excluding password from the response
    admins = []
    for record in admin_records:
        # Convert ObjectId to string
        record['_id'] = str(record['_id'])
        admins.append(record)
    return admins

# @admin_router.post('/update_admin_status')
# async def update_admin_status(request: Request,current_user: dict = Depends(get_current_user)):
#     data = await request.json()
#     admin_id = data.get('admin_id')
#     active_status = data.get('active_status')
    
#     result = db.users.update_one({"admin_id": admin_id}, {"$set": {"active_status": active_status}})
    
#     if result.matched_count == 0:
#         raise HTTPException(status_code=404, detail="Admin not found")
    
#     return {"message": "Admin status updated", "active_status": active_status, "status": 200}

# @admin_router.put("/admin_update_status")
# async def update_admin_status(request: Request):
#     try:
#         data = await request.json()
#         admin_id = data.get('admin_id')
#         new_status = data.get('status')

#         # Retrieve the current admin status
#         admin = db.users.find_one({"admin_id": admin_id})
#         if not admin:
#             raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Admin not found")

#         # Update the admin status
#         db.admin_status_history.insert_one({
#             "admin_id": admin_id,
#             "old_status": admin['active_status'],
#             "new_status": new_status,
#             "timestamp": datetime.now()
#         })
#         db.users.update_one({"admin_id": admin_id}, {"$set": {"active_status": new_status}})

#         return {"message": "Admin status updated successfully"}
#     except Exception as e:
#         raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# @admin_router.post('/admin/login')
# async def record_admin_login(request: Request):
#     data = await request.json()
#     admin_id = data.get('admin_id')
    
#     # Record the login event in the database
#     login_event = {
#         "admin_id": admin_id,
#         "timestamp": datetime.now()
#     }
#     db.admin_login_history.insert_one(login_event)
    
#     return {"message": "Admin login recorded successfully", "admin_id": admin_id}

# Endpoint to retrieve login history for a specific admin
@admin_router.get('/admin_login_history/{admin_id}')
async def get_admin_login_history(admin_id: int, current_user: dict = Depends(get_current_user)):
    try:
        # Retrieve login history for the specified admin ID
        login_history = list(db.admin_login_history.find({"admin_id": admin_id}))
        
        # Optionally, convert ObjectIds to strings for each document
        for login_event in login_history:
            login_event['_id'] = str(login_event['_id'])
        
        return login_history
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@admin_router.post('/update_admin_status')
async def update_admin_status(request: Request, current_user: dict = Depends(get_current_user)):
    data = await request.json()
    admin_id = data.get('admin_id')
    new_status = data.get('active_status')  # Assuming the new status is passed as 'active_status'

    # Retrieve the current admin status
    admin = db.users.find_one({"admin_id": admin_id})
    if not admin:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Admin not found")

    # Update the admin status
    db.admin_status_history.insert_one({
        "admin_id": admin_id,
        "old_status": admin['active_status'],
        "new_status": new_status,
        "timestamp": datetime.now()
    })
    db.users.update_one({"admin_id": admin_id}, {"$set": {"active_status": new_status}})

    return {"message": "Admin status updated successfully"}

@admin_router.get('/admin_status_history/{admin_id}')
async def get_admin_status_history(admin_id: str, current_user: dict = Depends(get_current_user)):
    try:
        admin_history = list(db.admin_status_history.find({"admin_id": admin_id}))
        print(admin_history)
        # Convert ObjectId to string for each document
        for history in admin_history:
            history['admin_id'] = str(history['admin_id'])
        return admin_history
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# @admin_router.post('/submit_document')
# async def submit_document(request: Request,current_user: dict = Depends(get_current_user)):
#     data = await request.json()
#     agreement_name = data.get('agreement_name')
#     print(agreement_name)
#     agreement_type = data.get('agreement_type')
#     document_base64 = data.get('document')
#     signers = data.get('signers', [])
#     watchers = data.get('watchers', [])
#     admin_id = data.get('admin_id')
    
#     admin_record = db.users.find_one({"admin_id": admin_id})
#     print(admin_record)
#     if not admin_record:
#         raise HTTPException(status_code=404, detail="Admin not found")

#     admin_email = admin_record['email']

#     # Decode and store the document
#     document_id = get_next_sequence(db, 'documentid')
#     document_path = save_document(document_base64, document_id)

#     # Set status for signers: first one 'in_progress' and others 'pending'
#     for i, signer in enumerate(signers):
#         signer['status'] = 'in_progress' if i == 0 else 'pending'

#     # Generate OTP and send to admin's email
#     otp = generate_otp(admin_email)
#     send_email(admin_email, "OTP Verification", f"Your OTP: {otp}")

#     # Temporarily store the details
#     temp_storage[admin_email] = {
#         "admin_id": admin_id,
#         "document_id": document_id,
#         "agreement_name": agreement_name,
#         "agreement_type": agreement_type,
#         "signers": signers, 
#         "watchers": watchers,
#         "document_path": document_path,
#         "document_base64": document_base64
#     }

#     return {"message": "Details submitted. OTP sent for verification.", "document_id": document_id, "status": 200}
    
@admin_router.delete('/remove_admin/{admin_id}')
async def remove_admin(admin_id: int, current_user: dict = Depends(get_current_user)):
    # Check if the current user has the necessary permissions to remove admins
    # verify_user_role(current_user)

    # Check if the admin to be removed exists
    admin = db.users.find_one({"admin_id": admin_id})
    if not admin:
        raise HTTPException(status_code=404, detail="Admin not found")

    # Remove the admin from the database
    db.users.delete_one({"admin_id": admin_id})

    return {"message": "Admin removed successfully", "status": 200}

@admin_router.post('/submit_document')
# @role_required('admin')
async def submit_document(data: dict = Body(...), current_user: dict = Depends(get_current_user)):
    agreement_name = data.get('agreement_name')
    agreement_type = data.get('agreement_type')
    document_base64 = data.get('document')
    signers = data.get('signers', [])
    watchers = data.get('watchers', [])
    admin_id = data.get('admin_id')
    admin_record = db.users.find_one({"admin_id": admin_id})
    if not admin_record:
        raise HTTPException(status_code=404, detail="Admin not found")

    admin_email = admin_record['email']

    # Decode and store the document
    document_id = get_next_sequence(db, 'documentid')
    document_path = save_document(document_base64, document_id)

    # Set status for signers: first one 'in_progress' and others 'pending'
    for i, signer in enumerate(signers):
        signer['status'] = 'in_progress' if i == 0 else 'pending'

    # Generate OTP and send to admin's email
    otp = generate_otp(admin_email)
    send_email(admin_email, "OTP Verification", f"Your OTP: {otp}")

    # Temporarily store the details
    temp_storage[admin_email] = {
        "admin_id": admin_id,
        "document_id": document_id,
        "agreement_name": agreement_name,
        "agreement_type": agreement_type,
        "signers": signers, 
        "watchers": watchers,
        "document_path": document_path,
        "original_documentbase64": document_base64,
        "document_base64": document_base64
    }

    return {"message": "Details submitted. OTP sent for verification.", "document_id": document_id, "status": 200}

# @admin_router.post('/verify_and_store_document')
# async def verify_and_store_document(request: Request):
#     otp_data = await request.json()
#     admin_email = otp_data.get('email')
#     otp = otp_data.get('otp')
    
#     if verify_otp(admin_email, otp):
#         document_data = temp_storage.pop(admin_email, None)
#         if document_data:
#             # Assign unique IDs to each signer and watcher
#             for signer in document_data['signers']:
#                 signer['signer_id'] = get_next_sequence(db, 'signerid')
#             for watcher in document_data['watchers']:
#                 watcher['watcher_id'] = get_next_sequence(db, 'watcherid')

#             # Store in DB
#             db.documents.insert_one(document_data)
#             return {"message": "Document and details stored successfully", "status": 200}
#         else:
#             raise HTTPException(status_code=404, detail="Session expired or invalid request")
#     else:
#         raise HTTPException(status_code=401, detail="Invalid or expired OTP")

@admin_router.post('/verify_and_store_document')
# @role_required('admin')
async def verify_and_store_document(otp_data: dict = Body(...), current_user: dict = Depends(get_current_user)):
    admin_email = otp_data.get('email')
    otp = otp_data.get('otp')
    # temp_storage[admin_email] = admin_email
    if verify_otp(admin_email, otp):
        document_data = temp_storage.pop(admin_email, None)
        if document_data:
            # Assign unique IDs to each signer and watcher
            for signer in document_data['signers']:
                signer['signer_id'] = get_next_sequence(db, 'signerid')
            for watcher in document_data['watchers']:
                watcher['watcher_id'] = get_next_sequence(db, 'watcherid')

            # Store in DB
            insert_result = db.documents.insert_one(document_data)
            document_id = insert_result.inserted_id
            notify_watchers_about_document_creation(document_data['watchers'], document_id, document_data)
            return {"message": "Document and details stored successfully", "status": 200}
        else:
            raise HTTPException(status_code=404, detail="Session expired or invalid request")
    else:
        raise HTTPException(status_code=401, detail="Invalid or expired OTP")

@admin_router.get('/get_documents')
async def get_admin_documents(request: Request, current_user: dict = Depends(get_current_user)):
    admin_id = request.query_params.get('admin_id')  # Assuming you pass the admin ID as a query parameter
    try:
        documents = list(db.documents.find({"admin_id": int(admin_id)}))
        # Optionally, exclude certain fields from the response
        for doc in documents:
            doc.pop('_id', None)  # Remove MongoDB's _id field

        return documents
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

async def protected_resource(user: dict = Depends(get_current_user)):
    verify_user_role(user)


